package com.gfk.api_test;

public class JsonOutputData {
	
	private String name;
	private String salary;
	private String age;
	private String id;
	
	public String getName() {
		return name;
	}
	public String getSalary() {
		return salary;
	}
	public String getAge() {
		return age;
	}
	public String getId() {
		return id;
	}
	
	
	
}
